<div class="container">
<div class="article">
<h1 class="single-title" itemprop="name"><?php the_title(); ?></h1> 
        <div class="article-info">
          <span><?php the_date('Y-m-d'); ?>&nbsp;<?php the_time('G:h'); ?></span>
          <span>字数: <?php echo count_words ($text); ?></span>
			<span>阅读量: <?php post_views(); ?></span>
      </div>
         <section class="entry clearfix" >
            <?php
                the_content('');
            ?>
        </section>
        
 </div>
<?php 
        if(comments_open( get_the_ID() ))  {
            comments_template('', true); 
        }
    ?>
</div></div>