<?php  get_header(); ?>
  <div class="container">
    <center><h1>额..神啊！发生神马事了...</h1>
<div id="sorry"></div>
    
      <p>
        可能是因为您的链接地址有误、该文章已经被作者删除或转为私密状态。
        <br>
        您可以尝试前往 <a href="<?php echo home_url(); ?>"><b>「<?php bloginfo('name'); ?>」</b>的首页</a>，或者直接联系我们： <a href="mailto:contact@jianshu.io">邮件</a>， <a href="http://weibo.com/229080567">微博</a>
      </p></center>
    </div>
  <?php get_footer(); ?>