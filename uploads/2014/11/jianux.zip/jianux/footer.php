<a class="go-top"><i class="icon-circle-arrow-up"></i></a>
<footer>
  <div class="copyright">
    © 2014 <a href="/" target="_blank"><?php bloginfo('name'); ?></a>
    <br>
    火星ICP备001号
  </div>
  <div class="contact">
    <a href="http://haikun.me/about/" target="_blank">关于</a>
    ·
<a href="http://haikun.me/guestbook" target="_blank">留言板</a>
    ·
<a href="http://haikun.me/weixin/" target="_blank">二维码</a>
    ·
<a href="http://haikun.me/web/" target="_blank">空间支持</a>
    ·
<a href="http://haikun.me/sitemap" target="_blank">网站地图</a>
    ·
<a href="http://haikun.me/mdemo" target="_blank">手机版</a>
    ·
    关注我:
    <a href="http://weibo.com/229080567" target="_blank"><i class="icon-weibo"></i></a>
  
    <br>
    <a href="" class="use-chrome">建议使用谷歌的 Chrome 浏览器访问以获得最佳用户体验</a>
  </div>
</footer>
    <script src="http://upcdn.b0.upaiyun.com/libs/jquery/jquery-1.10.2.min.js"></script>
<script>
    var week = new Date().getDay();
$('.cover-img').css("background-image","url(/wp-content/themes/jianux/images/"+week+".jpg)");  
</script>         
    <script src="<?php bloginfo('template_url'); ?>/js/full.js"></script>
<?php if( is_singular() ){ ?>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/comments-ajax.js"></script>
<?php } ?>
<?php wp_footer(); ?>
  </body>
</html>
