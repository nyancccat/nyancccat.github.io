<div class="container">
<div class="article">
<h1 class="single-title" itemprop="name"><?php the_title(); ?></h1> 
        <div class="article-info">
          <span>发表于 <i class="icon-book"></i><?php the_category('&nbsp;'); ?></span>
          <span><?php the_date('Y-m-d'); ?>&nbsp;<?php the_time('G:h'); ?></span>
          <span>字数: <?php echo count_words ($text); ?></span>
			<span>阅读量: <?php post_views(); ?></span><span><?php edit_post_link('[编辑]'); ?></span>
      </div>
         <section class="entry clearfix" >
            <?php
                the_content('');
            ?>
        </section>
        <div class="post-like">
         <a href="javascript:;" data-action="ding" data-id="<?php the_ID(); ?>" class="favorite<?php if(isset($_COOKIE['bigfa_ding_'.$post->ID])) echo ' done';?>"><i class="icon-heart"></i> 喜欢 <span class="count">
            <?php if( get_post_meta($post->ID,'bigfa_ding',true) ){            
                    echo get_post_meta($post->ID,'bigfa_ding',true);
                 } else {
                    echo '0';
                 }?></span>
        </a>
 </div>
		<div class="single-footer">
		
		<div class="prev-next">
		<?php 
				$prev_post = get_previous_post();
				$next_post = get_next_post(); ?>
		  <?php if($prev_post->post_title != "") { ?>
			   <a href="<?php echo get_permalink( $prev_post->ID ); ?>" class="before" title="<?php echo $prev_post->post_title; ?>"><i class="icon-arrow-left"></i><?php previous_post_link('上一篇: %link') ?></a>
		  <?php } ?>
		  <?php if($next_post->post_title != "") { ?>
               <a href="<?php echo get_permalink( $next_post->ID ); ?>" class="after" title="<?php echo $next_post->post_title; ?>"><?php next_post_link('下一篇: %link ') ?>  <i class="icon-arrow-right"></i></a>
		  <?php } ?>
		  </div>
</div>
</div>
<?php 
        if(comments_open( get_the_ID() ))  {
            comments_template('', true); 
        }
?>
</div></div>