<?php
/*
Template Name: Links
*/
?>


<?php get_header(); ?>

<div class="container">
<div class="article">
<h1 class="single-title" itemprop="name"><?php the_title(); ?></h1> 
 <br>      
<h3>鉴于有些网友总是问到友情链接的事情，特作如下声明：</h3>

<p>目前本站在网站首页不提供友情链接栏目。交换的链接都会放在这个独立页面<br>

申请友情链接的网站不限 PR，但应：<br>

内容健康，多为原创，至少已有 10 篇文章发布<br>

非 SEO 类、非采集类、非政治类、非盗版资讯类<br>

所有链接随机排列</p>

<b>本站链接名字：<a href="http://haikun.me/" target="_blank">千里草</a></b>
<br><hr>            
<div class="page-links">
   
    <ul>
        <?php
        $default_ico = get_template_directory_uri().'/images/links_default.ico'; //默认 ico 图片位置
        $bookmarks = get_bookmarks('title_li=&orderby=rand'); //全部链接随机输出
        //如果你要输出某个链接分类的链接，更改一下get_bookmarks参数即可
        //如要输出链接分类ID为5的链接 title_li=&categorize=0&category=5&orderby=rand
        if ( !empty($bookmarks) ) {
            foreach ($bookmarks as $bookmark) {
            echo '<li><img src="', $bookmark->link_url , '/favicon.ico" onerror="javascript:this.src=\'' , $default_ico , '\'" /><a href="' , $bookmark->link_url , '" title="' , $bookmark->link_description , '" target="_blank" >' , $bookmark->link_name , '</a></li>';
            }
        }
        ?>
    </ul>
</div>
        </section>
        
 </div>

</div></div>


<?php get_footer(); ?>